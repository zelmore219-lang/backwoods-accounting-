# Backwoods Production

Start with START.bat on Windows, or run `python server.py` and open http://127.0.0.1:8080. Python 3.10+ required; no packages needed. Your data stays in backwoods.db.

See DEPLOYMENT.md for PWA installation, backups, test instructions, mobile hosting requirements and deferred Backwoods integrations. See HANDOFF.md for the implementation checklist.

Open **Production Schedule** to see planned runs. Managers enter the date, batch count, approved recipe version, and instructions. Click a product or task to calculate ingredients and packaging for the full run and compare them with approved stock that will still be usable on the production date. Existing entries without a recipe need a manager to assign one. Planning does not reserve or consume stock.

Managers can add estimated labor and overhead to a run and see the estimated total cost. **Finished inventory** shows packages and pounds on hand. Managers also see actual cost per package and per pound, plus the cost of remaining stock. Pounds on hand are proportional to each batch's recorded finished weight.

Managers can select **Print inventory** on **Materials** or **Finished inventory** to use the browser print dialog. To package in a separate step, complete production as **Bulk (track by weight)** and approve the bulk lot. In **Finished inventory**, select **Package stock** and enter the new SKU, lot, package count, and net weight per package. Select an inventory packaging item to consume one per finished package, then enter packaging labor and any other packaging costs. The transfer reduces the source lot and creates a packaged lot awaiting inspection. For separate packaging, omit bags from the bulk recipe so their cost is charged only when used.

For direct production, add every ingredient and packaging item to the recipe, then record labor, energy, overhead, and other costs when completing the batch. Ingredient and packaging costs use the lots actually consumed. Managers can open **Cost breakdown** on a completed batch or finished lot to see the cost of each component, the batch total, and costs per pound and package.

Run checks: `python -m unittest test_suite test_http -v`.
